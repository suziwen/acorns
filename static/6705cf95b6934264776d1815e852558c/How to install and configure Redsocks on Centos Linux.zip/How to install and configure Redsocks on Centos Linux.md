---
title: How to install and configure Redsocks on Centos Linux
tags: 技术,代理,网络
createDate: 2021-8-4
slug: https://crosp.net/blog/administration/install-configure-redsocks-proxy-centos-linux/
---

> 本文为转载文章, 仅用于自己的知识管理收集, 如果涉及侵权,请联系 suziwen1@gmail.com,会第一时间删除
> 收集该文章,并非代表本人支持文中观点,只是觉得文章内容容易引起思考,讨论,有它自有的价值
>
> 转载自: https://crosp.net/blog/administration/install-configure-redsocks-proxy-centos-linux/


[toc!]

**Redsocks** is the tool that allows you to proxify(redirect) network traffic through a **SOCKS4**, **SOCKS5** or **HTTPs** proxy server. It works on the lowest level, the kernel level (**iptables**). The other possible way is to use **application level proxy**, when **the proxy client** is implemented in the same language as an application is written in. **Redsocks** operates on the lowest system level, that’s why all running application don’t even have an idea that network traffic is sent through a proxy server, as a result it is called a **transparent proxy redirector**.

## Prerequisites

If you are reading this article, you should probably have an idea why do you need to use **a proxy server**. Furthermore, you should be acquainted with basic proxy terms and definitions in order to understand everything described in this tutorial. It wouldn’t hurt to have some Linux administration skills as well.

For this tutorial I will be using **Centos 7 Minimal installation**, it has only the most essential applications installed. But you are free to use any distro, you may skip some steps then.

## How does Redsocks work ?

Before start installing **Redsocks**, I think it is always worth to know how something works internally. And it will help to understand this tool better and therefore troubleshoot issues.

First of all, **Redsocks** leverages features provided by **the Linux kernel firewall** (**Netfilter module**)

I hope this diagram will help you to understand the flow of a packet while using **Redsocks**.

![Redsocks packet flow](./images/1628091098582.png)

Here is a brief explanation how does a packet get redirected to **Redsocks**.

1.  When a packet is sent from an app in the system it is handled by the kernel, it triggers the **NT_ hooks** (defined in <linux/netfilter.h>).
2.  The **ip_tables kernel module** registers at **netfilter’s hooks** and proceed them according to defined rules.
3.  We are defining rules using **the iptables command line utility** (these rules will be described later in this article). And they are defined in the way that some or mostly all packets are redirected to the local process listening on a port, **12345** in case of **Redsocks**.
4.  All redirected packets are handled by **Redsokcs** conforming to the configuration file rules.
5.  **Redsocks** redirects packets to proxy servers.

## Step 1 — Getting Redsocks source code

First and foremost, you need to update repositories and installed software on the system.



```
yum update
```

In order to install **Redsocks** we need to compile it at first. Change into a directory you want to keep source code in.


```
cd /opt/
```

By default the **git command line tool** is not installed in most Centos distros. So install it at first.


```
yum install git
```

And clone **Redsocks source code** from the git repository.

```
git clone https://github.com/darkk/redsocks
```


Now change the directory to the **redsocks**.

```
cd redsocks/
```


Try to compile the application, but it will probably fail. In my case I don’t have even **make** installed.


```
[root@centos7 redsocks]# make
-bash: make: command not found
[root@centos7 redsocks]#

```

## Step 2 — Compiling Redsocks

Firstly you need to install **build-tools(Development Tools)** if you haven’t already.


```
yum group install "Development Tools"
```

Next, we need to install dependencies to successfully compile **Redsocks**.


```
yum install libevent libevent-devel
```

After installation try to compile **Redsocks** again using the **make** command. If compilation succeed you should see the compiled binary file in the current directory.

```
[root@centos7 redsocks]# ls -l redsocks
-rwxr-xr-x 1 root root 415968 Jul  7 08:49 redsocks
```

Now you can copy the binary file to any folder defined in **the $PATH variable**, to be able to execute it without specifying a full path to **Redsocks**.

## Step 3 — Setting Iptables Rules

To redirect necessary packets to **Redsocks** we need to define some **iptables rules**. I will use the rules suggested on [the official Redsocks page](http://darkk.net.ru/redsocks/).


```
# Create new chain
iptables -t nat -N REDSOCKS
```

The rule above creates a new custom chain in **the NAT table**.

Next we need to exclude all local and reserved network addresses. As a result all packets with the destination address from the following ranges will not be sent to **Redsocks**.


```
# Exclude local and reserved addresses
iptables -t nat -A REDSOCKS -d 0.0.0.0/8 -j RETURN
iptables -t nat -A REDSOCKS -d 10.0.0.0/8 -j RETURN
iptables -t nat -A REDSOCKS -d 127.0.0.0/8 -j RETURN
iptables -t nat -A REDSOCKS -d 169.254.0.0/16 -j RETURN
iptables -t nat -A REDSOCKS -d 172.16.0.0/12 -j RETURN
iptables -t nat -A REDSOCKS -d 192.168.0.0/16 -j RETURN
iptables -t nat -A REDSOCKS -d 224.0.0.0/4 -j RETURN
iptables -t nat -A REDSOCKS -d 240.0.0.0/4 -j RETURN
```

Now we need to add a rule that will redirect all packets from our custom **REDSOCKS chain** to the local port, we will use the default one – **12345**


```
iptables -t nat -A REDSOCKS -p tcp -j REDIRECT --to-ports 12345
```

Please note, this rule doesn’t redirect every packet sent in the system to **the port 12345**, it only redirects packets that are **already passed** inside **the REDSOCKS chain**. You can check this, for example using the following command.


```
wget google.com
```

Consequently, we need to define a rule that will redirect chosen packets by some criteria to **the REDSOCKS chain**. You are free to apply any rules you want, but I will show how to redirect all HTTP and HTTPS packets through a proxy. Define the following rules.


```
# Redirect all HTTP and HTTPS outgoing packets through Redsocks
iptables -t nat -A OUTPUT -p tcp --dport 443 -j REDSOCKS
iptables -t nat -A OUTPUT -p tcp --dport 80 -j REDSOCKS
```

Also you may need to define the following rules in the **PREROUTING chain**. For redirecting incomming packets to **the REDSOCKS chain**.

```
iptables -t nat -A PREROUTING -p tcp --dport 443 -j REDSOCKS
iptables -t nat -A PREROUTING -p tcp --dport 80 -j REDSOCKS
iptables -t nat -A PREROUTING -p tcp --dport 1080 -j REDSOCKS
```

Do not be confused about these rules. They are applied only for incoming packets, that’s why the chain is called **PRE ROUTING**. Here is the diagram that shows **the packet flow** through **iptables tables and chains**.

![](./images/1628091098586.png)

Furthermore, you are free to define any rules you need, just remember to jump **(-j REDSOCKS)** to the **REDSOCKS chain**. Here another example from the official documentation. It redirects only packets sent **from a specific user**, this could be very useful in some cases. You can follow the **user per application strategy (similar used in Android)**, as a result you will be able set **application specific rules**.

```
iptables -t nat -A OUTPUT -p tcp -m owner --uid-owner crosp -j REDSOCKS
```

One more important point, avoid using **the root user** in **iptables rules** or you may get stuck in **the infinite loop**. Here is [a problem](https://github.com/darkk/redsocks/issues/108) I’ve encountered because of my inattention.

Having set iptables rules the final step is to **configure Redsocks** itself using the configuration file.

## Step 4 — Configuring Redsocks

Create a file with the name **redsocks.conf** in the same directory (or any other directory) where the binary file is located. And let’s start by defining the **base section** of the configuration file as follows.


```
base {
 log_debug = on;
 log_info = on;
 log = "stderr";
 daemon = off;
 redirector = iptables;
}
```
I think each parameter is self-explanatory. You can find a complete description of every option in the example of [configuration file](https://github.com/darkk/redsocks/blob/master/redsocks.conf.example) in the [official repository](https://github.com/darkk/redsocks).

Next we need to define **proxies**. This is done using **redsocks sections**. Here is an example of a possible proxy configuration.


```
redsocks {
    // Local IP listen to
    local_ip = 127.0.0.1;
    // Port to listen to
    local_port = 12345;
    // Remote proxy address
    ip = super.socks.proxy.com;
    port = 9966;
    // Proxy type
    type = socks5;
    // Username to authorize on proxy server
    login = anonymous;
    // Password for a proxy user
    password = verystrongpassword;
    // Do not disclose real IP
    disclose_src = false;
}
```

As you can see from the configuration above, this is the **SOCKS5 proxy configuration**. Redsocks will listen to the **port 12345**. We have provided credentials to authenticate ourselves on the proxy server as well.

You create multiple **redsocks sections**. But you have to specify **a different local port** and as a result you need to set **appropriate iptables rules**.

```
redsocks {
    // Local IP listen to
    local_ip = 127.0.0.1;
    // Port to listen to
    local_port = 83333;
    // Remote proxy address
    ip = puper.socks.proxy.com;
    port = 6699;
    // Proxy type
    type = socks5;
    // Username to authorize on proxy server
    login = anonymous2;
    // Password for a proxy user
    password = verystrongpassword;
    // Do not disclose real IP
    disclose_src = false;
}
```

As an example, you can use the tricky technique to simulate **load balancing** with the help of **the random module**.

```
iptables -t nat -A REDSOCKS -p tcp -m random --mode random --probability 0.5 -j REDIRECT --to-ports 83333
iptables -t nat -A REDSOCKS -p tcp -j REDIRECT --to-ports 12345
```

There are lot of other ways to define iptables rules for using with **multiple proxies**, for instance you can use **the mangle table**, **create another chain** (ex. REDSOCKS_HTTP) and so on.

## Step 5 — Testing proxies with Redsocks

Now it is time to test our configuration. Save the configuration file. Navigate to the folder with the **Redsocks compiled executable file**. And execute the following command.

```
./redsocks -c /etc/redsocks.conf
```

If your configuration file is valid and there are no other errors you should almost return immediately in case or running in **the daemon mode** or see the similar output **with the daemon mode off**.

```
1499876514.801445 notice main.c:165 main(...) redsocks started, conn_max=128
```

Furthermore, you can use **the netstat tool** to get list of processes **bound to ports**.

```
[root@centos ~]# netstat -tulpn
Active Internet connections (only servers)
Proto Recv-Q Send-Q Local Address           Foreign Address         State       PID/Program name
tcp        0      0 127.0.0.1:27017         0.0.0.0:*               LISTEN      533/mongod
tcp        0      0 0.0.0.0:22              0.0.0.0:*               LISTEN      50/sshd
tcp        0      0 127.0.0.1:12345         0.0.0.0:*               LISTEN      465/./redsocks
tcp6       0      0 :::22                   :::*                    LISTEN      50/sshd
udp        0      0 0.0.0.0:14332           0.0.0.0:*                           229/dhclient
udp        0      0 0.0.0.0:68              0.0.0.0:*                           229/dhclient
udp6       0      0 :::28185                :::*                                229/dhclient
```


Now try to make any request as **the specified user** or to match a rule you defined on your own. For example, use the following curl request to get **your external IP address**.

```
curl 'https://api.ipify.org?format=json'
```


If **the redsocks process** is attached to the terminal, you should see something like that in **stderr**.

```
1499882494.465788 info redsocks.c:1243 redsocks_accept_client(...) [192.168.0.128:34470->50.19.238.1:443]: accepted
1499882495.249026 debug redsocks.c:341 redsocks_start_relay(...) [192.168.0.128:34470->50.19.238.1:443]: data relaying started
1499882496.359465 info redsocks.c:671 redsocks_drop_client(...) [192.168.0.128:34470->50.19.238.1:443]: connection closed
```

If you encountered any error check debug output in the first place.

## Conclusion

In this tutorial I’ve described how to install **Redsocks** on **Centos 7**. Redsocks provides a very convenient way to configure a proxy environment, starting from a single proxy server to a dozens of proxies of different type. In addition if you are missing some features [in the original project](https://github.com/darkk/redsocks), you can check out a fork – [Redsocks2](https://github.com/semigodking/redsocks).

I hope this tutorial was useful for you. If you have any troubles with setting up Redsocks, please feel free to leave comments below.